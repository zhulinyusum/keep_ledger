import JournalFeature from '@/components/journal/journal-feature';

export default function Page() {
  return <JournalFeature />;
}
