import AccountListFeature from '@/components/account/account-list-feature';

export default function Page() {
  return <AccountListFeature />;
}
