import AccountDetailFeature from '@/components/account/account-detail-feature';

export default function Page() {
  return <AccountDetailFeature />;
}
