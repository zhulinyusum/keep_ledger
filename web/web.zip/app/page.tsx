import DashboardFeature from '@/components/dashboard/dashboard-feature';

export default function Page() {
  return <DashboardFeature />;
}
