import ReportFeature from "@/components/ledger/ledgr-select/report/report-feature";

export default function Page() {
  return <ReportFeature />;
}
