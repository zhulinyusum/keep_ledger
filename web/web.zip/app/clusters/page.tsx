import ClusterFeature from '@/components/cluster/cluster-feature';

export default function Page() {
  return <ClusterFeature />;
}
